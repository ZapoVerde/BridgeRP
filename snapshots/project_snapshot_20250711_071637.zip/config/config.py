# config.py
# Controls global debug behavior for ParetoDebug

DEBUG_MODE = True
