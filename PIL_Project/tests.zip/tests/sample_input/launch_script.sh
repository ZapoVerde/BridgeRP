# tests/sample_input/assets/launch_script.sh
#!/bin/bash
echo "Launching fireball..."
