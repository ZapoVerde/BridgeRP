# func (in module)
> **Fully qualified name:** `sample.module.func`

**Type:** function
**Module:** sample.module
**Status:** active
**Visibility:** public
**Tags:** #sample #test #exporter
**Deprecated:** ❌

---

## Description
Sample function description.

## Full Docstring
```
This is a sample function for testing.
```

## Links
None

---
